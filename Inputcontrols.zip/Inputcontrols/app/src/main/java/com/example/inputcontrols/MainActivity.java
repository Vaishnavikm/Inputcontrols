package com.example.inputcontrols;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name, pass;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText) findViewById(R.id.name);
        pass = (EditText)findViewById(R.id.pass);
        submit = (Button) findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!name.getText().toString().isEmpty() && !pass.getText().toString().isEmpty())
                {
                    String wel = "Welcome "+name.getText().toString();
                    Toast.makeText(MainActivity.this, wel , Toast.LENGTH_SHORT).show();
                    Intent login =new Intent(MainActivity.this, SecondActivity.class);
                    startActivity(login);
                }
                else {
                    Toast.makeText(MainActivity.this, "Details missing", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        
    }
}